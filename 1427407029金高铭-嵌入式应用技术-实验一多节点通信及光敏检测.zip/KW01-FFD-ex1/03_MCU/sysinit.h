

#ifndef SYSINIT_H_
#define SYSINIT_H_

#include "common.h"
#include "vectors.h"


void sys_init(void);

#endif 
